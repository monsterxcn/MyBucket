#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from PIL import Image

path = "/data/qbot/SBot/src/plugins/__nonebot_plugin_gshelper/images/"

def select(type, day):
  imgList = []
  filename = f'{type}.{day}.png'
  width, height = (0, 0)
  if day != 7:
    daily = day if day < 4 else day - 3
    countries = ["Mondstadt", "Liyue", "Inazuma"]
    imgList.append(Image.open(path + f"{type}.png"))
    for country in countries:
      image = path + f"{type}.{country}.{daily}.png"
      imgList.append(Image.open(image))
    for img in imgList:
      w, h = img.size
      height += h
      width = max(width, w)
  return imgList, width, height, filename

def combine(imgList, totalWidth, totalHeight, saveAs):
  if imgList == []:
    return "哈！今天是周日，所有天赋秘境和武器秘境全部开放哦🥰"
  else:
    result = Image.new(imgList[0].mode, (totalWidth, totalHeight), "#F6F2EE")
    drawFromHeight = 0
    for img in imgList:
      w, h = img.size
      result.paste(img, box=(round(width / 2 - w / 2), drawFromHeight))
      drawFromHeight += h
    result.save(saveAs)
    return "[CQ:image,file={}{}]".format(path, saveAs)

if __name__ == '__main__':
    imgList, width, height, picname = select("weapon", 3)
    msg = combine(imgList, width, height, picname)
    print(msg)
