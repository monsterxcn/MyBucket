#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
from PIL import Image

# startFlags = ['talent.Mondstadt', 'weapon.Mondstadt', 'talent.Liyue', 'weapon.Liyue', 'talent.Inazuma', 'weapon.Inazuma']

path = "/data/qbot/SBot/src/plugins/__nonebot_plugin_gshelper/images/"
type = 'talent'
day = 1

if __name__ == '__main__':
# for startFlag in startFlags:
  im_list = []
  # tmp = Image.new("RGB", (772, 140), "#F6F2EE")
  for fn in sorted(os.listdir(path), reverse=False):
    # if fn.startswith(startFlag):
    if fn == 'weapon.Mondstadt.ShiYaDouShi.1.png':
      im_list.append(Image.open(path + os.sep + fn))
      print(fn)

  count = 1
  for img in im_list:
    w, h = img.size
    width = w + 13
    height = 140 if h == 80 else h
    result = Image.new("RGBA", (width, height), "#F6F2EE")
    startheight = 30 if height == 140 else 0
    result.paste(img, box=(0, startheight))
    # result.save(f'{startFlag}.{count}.{count}.png')
    # print(f"newPicture saved: {startFlag}.{count}.{count}.png")
    result.save(f'weapon.Mondstadt.3.png')
    print(f"newPicture saved: weapon.Mondstadt.3.png")
    count += 1